/*
 This source file is part of the Swift System open source project

 Copyright (c) 2024 Apple Inc. and the Swift System project authors
 Licensed under Apache License v2.0 with Runtime Library Exception

 See https://swift.org/LICENSE.txt for license information
*/

import XCTest

#if os(Windows)

#if SYSTEM_PACKAGE
@testable import SystemPackage
#else
@testable import System
#endif

import WinSDK
import ucrt

private let FILE_APPEND_DATA = DWORD(WinSDK.FILE_APPEND_DATA)
private let FILE_EXECUTE = DWORD(WinSDK.FILE_EXECUTE)
private let FILE_READ_ATTRIBUTES = DWORD(WinSDK.FILE_READ_ATTRIBUTES)

@available(iOS 8, *)
final class FileOperationsTestWindows: XCTestCase {
  private let r = ACCESS_MASK(
    FILE_READ_ATTRIBUTES
      | FILE_READ_DATA
      | FILE_READ_EA
      | STANDARD_RIGHTS_READ
      | SYNCHRONIZE
  )
  private let w = ACCESS_MASK(
    FILE_APPEND_DATA
      | FILE_WRITE_ATTRIBUTES
      | FILE_WRITE_DATA
      | FILE_WRITE_EA
      | STANDARD_RIGHTS_WRITE
      | SYNCHRONIZE
  )
  private let x = ACCESS_MASK(
    FILE_EXECUTE
      | FILE_READ_ATTRIBUTES
      | STANDARD_RIGHTS_EXECUTE
      | SYNCHRONIZE
  )

  private let none = ACCESS_MASK(0)

  private struct Test {
    var permissions: CModeT
    var ownerAccess: ACCESS_MASK
    var groupAccess: ACCESS_MASK
    var otherAccess: ACCESS_MASK

    init(_ permissions: CModeT,
         _ ownerAccess: ACCESS_MASK,
         _ groupAccess: ACCESS_MASK,
         _ otherAccess: ACCESS_MASK) {
      self.permissions = permissions
      self.ownerAccess = ownerAccess
      self.groupAccess = groupAccess
      self.otherAccess = otherAccess
    }
  }

  /// Retrieve the owner, group and other access masks for a given file.
  ///
  /// - Parameters:
  ///   - path: The path to the file to inspect
  /// - Returns: A tuple of ACCESS_MASK values.
  func getAccessMasks(
    path: FilePath
  ) -> (ACCESS_MASK, ACCESS_MASK, ACCESS_MASK) {
    var SIDAuthWorld = SID_IDENTIFIER_AUTHORITY(Value: (0, 0, 0, 0, 0, 1))
    var psidEveryone: PSID? = nil

    XCTAssert(AllocateAndInitializeSid(&SIDAuthWorld, 1,
                                       SECURITY_WORLD_RID,
                                       0, 0, 0, 0, 0, 0, 0,
                                       &psidEveryone))
    defer {
      FreeSid(psidEveryone)
    }

    var everyone = TRUSTEE_W(
      pMultipleTrustee: nil,
      MultipleTrusteeOperation: NO_MULTIPLE_TRUSTEE,
      TrusteeForm: TRUSTEE_IS_SID,
      TrusteeType: TRUSTEE_IS_GROUP,
      ptstrName:
        psidEveryone!.assumingMemoryBound(to: CInterop.PlatformChar.self)
    )

    return path.withPlatformString { objectName in
      var psidOwner: PSID? = nil
      var psidGroup: PSID? = nil
      var pDacl: PACL? = nil
      var pSD: PSECURITY_DESCRIPTOR? = nil

      XCTAssertEqual(GetNamedSecurityInfoW(
                       objectName,
                       SE_FILE_OBJECT,
                       SECURITY_INFORMATION(
                         DACL_SECURITY_INFORMATION
                           | GROUP_SECURITY_INFORMATION
                           | OWNER_SECURITY_INFORMATION
                       ),
                       &psidOwner,
                       &psidGroup,
                       &pDacl,
                       nil,
                       &pSD), ERROR_SUCCESS)
      defer {
        LocalFree(pSD)
      }

      var owner = TRUSTEE_W(
        pMultipleTrustee: nil,
        MultipleTrusteeOperation: NO_MULTIPLE_TRUSTEE,
        TrusteeForm: TRUSTEE_IS_SID,
        TrusteeType: TRUSTEE_IS_USER,
        ptstrName:
          psidOwner!.assumingMemoryBound(to: CInterop.PlatformChar.self)
      )
      var group = TRUSTEE_W(
        pMultipleTrustee: nil,
        MultipleTrusteeOperation: NO_MULTIPLE_TRUSTEE,
        TrusteeForm: TRUSTEE_IS_SID,
        TrusteeType: TRUSTEE_IS_GROUP,
        ptstrName:
          psidGroup!.assumingMemoryBound(to: CInterop.PlatformChar.self)
      )

      var ownerAccess = ACCESS_MASK(0)
      var groupAccess = ACCESS_MASK(0)
      var otherAccess = ACCESS_MASK(0)

      XCTAssertEqual(GetEffectiveRightsFromAclW(
                       pDacl,
                       &owner,
                       &ownerAccess), ERROR_SUCCESS)
      XCTAssertEqual(GetEffectiveRightsFromAclW(
                       pDacl,
                       &group,
                       &groupAccess), ERROR_SUCCESS)
      XCTAssertEqual(GetEffectiveRightsFromAclW(
                       pDacl,
                       &everyone,
                       &otherAccess), ERROR_SUCCESS)

      return (ownerAccess, groupAccess, otherAccess)
    }
  }

  private func runTests(_ tests: [Test], at path: FilePath) throws {
    for test in tests {
      let octal = String(test.permissions, radix: 8)
      let testPath = path.appending("test-\(octal).txt")
      let fd = try FileDescriptor.open(
        testPath,
        .readWrite,
        options: [.create, .truncate],
        permissions: FilePermissions(rawValue: test.permissions)
      )
      _ = try fd.closeAfter {
        try fd.writeAll("Hello World".utf8)
      }

      let (ownerAccess, groupAccess, otherAccess)
        = getAccessMasks(path: testPath)

      XCTAssertEqual(ownerAccess, test.ownerAccess)
      XCTAssertEqual(groupAccess, test.groupAccess)
      XCTAssertEqual(otherAccess, test.otherAccess)
    }
  }

  /// Test that the umask works properly
  func testUmask() throws {
    // See https://learn.microsoft.com/en-us/virtualization/windowscontainers/manage-containers/persistent-storage#permissions
    try XCTSkipIf(NSUserName() == "ContainerAdministrator", "containers use a different permission model")
    
    // Default mask should be 0o022
    XCTAssertEqual(FilePermissions.creationMask, [.groupWrite, .otherWrite])

    try withTemporaryFilePath(basename: "testUmask") { path in
      let tests = [
        Test(0o000, none, none, none),
        Test(0o700, r|w|x, none, none),
        Test(0o770, r|w|x, r|x, none),
        Test(0o777, r|w|x, r|x, r|x)
      ]

      try runTests(tests, at: path)
    }

    try FilePermissions.withCreationMask([.groupWrite, .groupExecute,
                                          .otherWrite, .otherExecute]) {
      try withTemporaryFilePath(basename: "testUmask") { path in
        let tests = [
          Test(0o000, none, none, none),
          Test(0o700, r|w|x, none, none),
          Test(0o770, r|w|x, r, none),
          Test(0o777, r|w|x, r, r)
        ]

        try runTests(tests, at: path)
      }
    }
  }

  /// Test that setting permissions on a file works as expected
  func testPermissions() throws {
    // See https://learn.microsoft.com/en-us/virtualization/windowscontainers/manage-containers/persistent-storage#permissions
    try XCTSkipIf(NSUserName() == "ContainerAdministrator", "containers use a different permission model")

    try FilePermissions.withCreationMask([]) {
      try withTemporaryFilePath(basename: "testPermissions") { path in
        let tests = [
          Test(0o000, none, none, none),

          Test(0o400, r, none, none),
          Test(0o200, w, none, none),
          Test(0o100, x, none, none),
          Test(0o040, none, r, none),
          Test(0o020, none, w, none),
          Test(0o010, none, x, none),
          Test(0o004, none, none, r),
          Test(0o002, none, none, w),
          Test(0o001, none, none, x),

          Test(0o700, r|w|x, none, none),
          Test(0o770, r|w|x, r|w|x, none),
          Test(0o777, r|w|x, r|w|x, r|w|x),

          Test(0o755, r|w|x, r|x, r|x),
          Test(0o644, r|w, r, r),

          Test(0o007, none, none, r|w|x),
          Test(0o070, none, r|w|x, none),
          Test(0o077, none, r|w|x, r|w|x),
        ]

        try runTests(tests, at: path)
      }
    }
  }

  /// Test that buffer sizes exceeding DWORD.max (4GB) are properly rejected
  func testBufferSizeLimit() throws {
    try withTemporaryFilePath(basename: "testBufferSizeLimit") { path in
      let fd = try FileDescriptor.open(
        path.appending("test.txt"),
        .readWrite,
        options: [.create, .truncate],
        permissions: .ownerReadWrite
      )
      defer { try? fd.close() }

      // Write some data first
      try fd.writeAll("test data".utf8)

      // Allocate a small buffer for testing
      let buffer = UnsafeMutableRawBufferPointer.allocate(byteCount: 1024, alignment: 1)
      defer { buffer.deallocate() }

      // Test that a count exceeding DWORD.max (UInt32.max = 4,294,967,295) returns EINVAL
      // We use a buffer pointer but pass a count > DWORD.max
      let oversizedCount = Int(DWORD.max) + 1
      let oversizedBuffer = UnsafeMutableRawBufferPointer(
        start: buffer.baseAddress,
        count: oversizedCount
      )

      // pread should fail with EINVAL
      do {
        _ = try fd.read(fromAbsoluteOffset: 0, into: oversizedBuffer)
        XCTFail("Expected EINVAL for buffer size exceeding DWORD.max")
      } catch let err as Errno {
        XCTAssertEqual(err, .invalidArgument, "Expected EINVAL, got \(err)")
      }

      // pwrite should also fail with EINVAL
      do {
        _ = try fd.write(toAbsoluteOffset: 0, UnsafeRawBufferPointer(oversizedBuffer))
        XCTFail("Expected EINVAL for buffer size exceeding DWORD.max")
      } catch let err as Errno {
        XCTAssertEqual(err, .invalidArgument, "Expected EINVAL, got \(err)")
      }

      // Verify that exactly DWORD.max works (if we had a buffer that large)
      // We can't easily test this without allocating 4GB, but the boundary is correct
    }
  }

  func testCloseOnExecOpenOption() throws {
    try withTemporaryFilePath(basename: "testCloseOnExec") { path in

      func hasInheritFlag(of fd: FileDescriptor) throws -> Bool {
        let osfHandle = _get_osfhandle(fd.rawValue)
        let handle = try XCTUnwrap(HANDLE(bitPattern: osfHandle))
        var flags: DWORD = 0
        XCTAssertTrue(GetHandleInformation(handle, &flags))
        return flags & DWORD(HANDLE_FLAG_INHERIT) == DWORD(HANDLE_FLAG_INHERIT)
      }

      var fd: FileDescriptor
      fd = try FileDescriptor.open(
        path.appending("wontinherit.txt"), .readWrite,
        options: [.create, .truncate, .closeOnExec],
        permissions: .ownerReadWrite
      )
      try fd.closeAfter {
        XCTAssertEqual(try hasInheritFlag(of: fd), false)
      }

      fd = try FileDescriptor.open(
        path.appending("inheritable.txt"), .readWrite,
        options: [.create, .truncate],
        permissions: .ownerReadWrite
      )
      try fd.closeAfter {
        XCTAssertEqual(try hasInheritFlag(of: fd), true)
      }
    }
  }
}

#endif // os(Windows)
